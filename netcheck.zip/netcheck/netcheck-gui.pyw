"""Double-clickable launcher for the netcheck GUI.

Saved with a .pyw extension so Windows opens it with pythonw.exe: the window
appears on its own, with no console behind it. Double-click this file, or run
it from a terminal with `python netcheck-gui.pyw`.

Works from a bare clone as well as an installed copy - the project directory is
added to sys.path so `pip install` is not required just to launch the GUI.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from netcheck.gui import main

if __name__ == "__main__":
    sys.exit(main())
