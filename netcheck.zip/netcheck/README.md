# netcheck

A command-line network troubleshooting tool, with a desktop GUI. It runs the
standard battery of diagnostics against a host — **ping**, **traceroute**,
**DNS resolution**, and **TCP port checks** — captures the raw output, and
hands that output to an LLM to explain what it means and what to try next.

You get both halves: the unedited tool output, and an interpretation of it.

```sh
netcheck example.com          # command line
python netcheck-gui.pyw       # desktop window (or double-click the file)
```

## Why

The hard part of network troubleshooting usually isn't collecting the data —
it's reading it. A traceroute with stars at hops 1 and 4 looks alarming until
you know that routers commonly suppress ICMP TTL-exceeded messages. Port 22
timing out on a Cloudflare-fronted host isn't a firewall misconfiguration on
your end; Cloudflare simply doesn't proxy SSH.

netcheck runs the commands you'd run anyway, then puts an experienced reader
next to the output. The raw results are always printed, so the interpretation
is something you can check rather than something you have to trust.

## What it runs

| Probe | Windows | macOS / Linux | Tells you |
|---|---|---|---|
| ping | `ping -n 4` | `ping -c 4` | Reachability, latency, packet loss |
| traceroute | `tracert -h 20` | `traceroute -m 20` | The path taken, and where it breaks |
| DNS | `nslookup` | `dig` | Name resolution, plus the client's own view |
| ports | Python `socket` | Python `socket` | Whether a service is listening or filtered |

Two details worth knowing:

- **The DNS probe reports two views.** It runs the native tool *and* Python's
  `socket.getaddrinfo`, because they can disagree in ways that matter. `dig`
  exits 0 even on NXDOMAIN, and a native tool may be missing entirely — but
  `getaddrinfo` is what an actual client process experiences.
- **Port checks distinguish refused from filtered.** A refused connection means
  the host is reachable with nothing listening; a timeout usually means a
  firewall dropped the packet. Those point at very different problems.

## Install

Requires Python 3.10+.

```sh
git clone <your-repo-url>
cd netcheck
python -m pip install -e .
```

The probes have **no runtime dependencies** — they use the OS's own network
tools and the standard library. `netcheck --no-ai` and the GUI both work on a
fresh install with nothing else configured.

The AI diagnosis needs a provider SDK, installed as an extra:

```sh
python -m pip install -e ".[anthropic]"   # or ".[openai]", or ".[all]"
```

On Linux the native tools may not be present in minimal images:

```sh
sudo apt install traceroute dnsutils   # traceroute, dig
```

## Configure the AI step

Anthropic's Claude is the default. Set a key:

```sh
export ANTHROPIC_API_KEY=sk-ant-...        # PowerShell: $env:ANTHROPIC_API_KEY = "sk-ant-..."
```

To use OpenAI instead:

```sh
export OPENAI_API_KEY=sk-...
netcheck example.com --provider openai
```

If no key is configured, netcheck still prints every raw result and notes that
the diagnosis was skipped — a missing key is never a fatal error.

## Usage

```
netcheck TARGET [options]

  -p, --port PORT   extra TCP port to check; repeatable (defaults: 22, 80, 443)
  --no-ports        skip the default ports; combine with -p to check only yours
  --no-ai           skip the LLM diagnosis and run fully offline
  --provider        anthropic (default) or openai
  --effort          low | medium | high | xhigh | max   (Anthropic only)
  --json            emit a machine-readable report
  -v, --verbose     print each probe command as it runs
```

`TARGET` can be a hostname, an IP address, or a URL — `https://example.com/path`
and `example.com:8080` are both reduced to `example.com`.

```sh
netcheck 10.0.0.1 --no-ai                  # offline, no API key needed
netcheck db.internal --no-ports -p 5432    # check exactly one port
netcheck example.com --json > report.json  # for scripting
```

**Exit codes:** `0` all probes healthy · `1` at least one probe reported a
problem · `2` bad arguments. The exit code reflects the probes only, so a
missing API key never masks a healthy target.

## Sample output

Real output, abbreviated in the middle for length:

```
========================================================================
netcheck: example.com
========================================================================

--- ping [ok] (3.2s) ---------------------------------------------------
$ ping -n 4 -w 4000 example.com

Pinging example.com [104.20.23.154] with 32 bytes of data:
Reply from 104.20.23.154: bytes=32 time=41ms TTL=53
Reply from 104.20.23.154: bytes=32 time=39ms TTL=53

Ping statistics for 104.20.23.154:
    Packets: Sent = 4, Received = 4, Lost = 0 (0% loss),

--- traceroute [ok] (40.3s) --------------------------------------------
$ tracert -h 20 -w 1000 example.com

  1     *        *        *     Request timed out.
  2   224 ms    42 ms   120 ms  172.20.21.254
  ...
  9    62 ms    52 ms    53 ms  162.158.20.42
 10   151 ms    79 ms    89 ms  104.20.23.154

--- dns [ok] (0.4s) ----------------------------------------------------
$ nslookup example.com

Name:    example.com
Addresses:  2606:4700:10::ac42:93f3
          104.20.23.154

[python socket.getaddrinfo] OK: 2 address(es)
  104.20.23.154  (AF_INET)
  172.66.147.243  (AF_INET)

--- ports [problem] (6.0s) ---------------------------------------------
$ python socket.create_connection (parallel)

TCP connect checks on example.com (3s timeout each, run in parallel)
     22/tcp  timeout    no response within 3s - typically a firewall drop
     80/tcp  open       connected to 104.20.23.154:80 in 40 ms
    443/tcp  open       connected to 104.20.23.154:443 in 39 ms
   8080/tcp  open       connected to 104.20.23.154:8080 in 39 ms
3/4 open - all checks finished in 6.0s

========================================================================
AI DIAGNOSIS (anthropic/claude-opus-5)
========================================================================

## Verdict: healthy

example.com is reachable and behaving normally. Every signal that matters is
green, and the one "failure" in the port scan is expected rather than a problem.

**Reachability and latency** - 4/4 ICMP replies, 0% loss, 34-40ms with ~6ms
jitter. Traceroute completes cleanly to the destination in 10 hops. The timeouts
at hops 1 and 4 are routers declining to send ICMP TTL-exceeded messages, not
packet loss; the trace continues past both with stable timings, which rules out
a break at those points.

**Ports** - 80, 443, and 8080 all connect in ~40ms. That trio is characteristic
of a Cloudflare edge, so 8080 being open tells you about the CDN, not about an
application listening on the origin. Port 22 timing out is the correct result:
Cloudflare doesn't proxy SSH, so the SYN is dropped at the edge. A timeout
rather than a connection refused is the expected signature there.
```

## The desktop app

Three ways to launch it, in order of convenience:

```sh
# 1. Double-click netcheck-gui.pyw in the project folder (Windows).
#    Opens the window with no console behind it.

# 2. From a terminal in the project folder - no install needed:
python netcheck-gui.pyw
python -m netcheck.gui
python -m netcheck.gui example.com    # pre-fill the target field

# 3. As an installed command, after `pip install -e .`:
netcheck-gui
```

Built on tkinter from the standard library, so there is nothing extra to
install — the GUI works on a fresh clone.

> **If `netcheck-gui` says "command not found"**, pip installed it to a folder
> that isn't on your PATH. Use option 1 or 2 above, or add the directory pip
> named in its install warning to PATH. On Windows that is usually
> `%APPDATA%\Python\Python3xx\Scripts`.

```
┌─ Target ──────────────────────────────────────────────────┐
│ Host or URL: [ example.com          ]  [ Run ] [ Cancel ]  │
│ TCP ports:   [ 22, 80, 443          ]                      │
│ [x] AI diagnosis   Provider: [anthropic v]  Effort: [medium v] │
└────────────────────────────────────────────────────────────┘
┌─ Progress ────────────────────────────────────────────────┐
│ Ping         ok                                     3.2s   │
│ Traceroute   ok                                    40.3s   │
│ DNS          ok                                     0.4s   │
│ TCP ports    problem (exit 1)                       6.0s   │
│ ████████████████████████████████████████████████████████   │
│ Done - one or more probes reported a problem.              │
└────────────────────────────────────────────────────────────┘
┌ AI diagnosis │ Raw output ───────────────────────────────┐
│                                                           │
│  ## Verdict: healthy                                      │
│  example.com is reachable and behaving normally...        │
└───────────────────────────────────────────────────────────┘
  [ Save report... ]  [ Copy to clipboard ]
```

The probes run on a worker thread, so the window stays responsive during a
40-second traceroute. Each probe's result appears the moment it lands rather
than everything arriving at the end. **Cancel** stops the run after the
current probe finishes — an in-flight subprocess is left to complete under its
own timeout rather than being killed, and the progress bar pulses while that
plays out. **Save report...** writes either the text report or JSON, chosen by
the file extension.

The GUI calls the same `runner.py` and `analyzer.py` functions as the CLI and
renders through the same `render()`, so the two interfaces cannot drift apart.

## How it works

```
cli.py ─┐
        ├─▶ core.py ──▶ runner.py   run probes, capture raw output
gui.py ─┘           └─▶ analyzer.py send that output to an LLM
```

| File | Responsibility |
|---|---|
| `netcheck-gui.pyw` | Double-clickable launcher for the GUI (no console window) |
| `cli.py` | Argument parsing, text and JSON rendering, exit codes |
| `gui.py` | Tkinter window, worker thread, live progress |
| `core.py` | Target normalization, orchestration, the `Report` type |
| `runner.py` | The four probes; subprocess handling, timeouts, encoding |
| `analyzer.py` | Prompt construction and provider calls |

A few decisions that shaped the code:

- **Raw output is never rewritten.** The bytes shown to the user are the bytes
  sent to the model, so the diagnosis can always be checked against the
  evidence.
- **Each probe gets its own timeout budget.** Traceroute is allowed 90s because
  20 hops × 3 probes legitimately takes a while; ping gets 30s. A probe that
  overruns is reported with its partial output rather than failing the run.
- **Port checks run in parallel** in a thread pool; the network probes run in
  sequence so the report reads top-to-bottom the way you'd work through it.
- **The AI step can never break the report.** Any analyzer failure — missing
  key, missing SDK, rate limit, refusal — is caught and rendered as a note
  beneath the results.
- **Windows console output is decoded as OEM codepage**, not UTF-8, so
  `tracert`'s box-drawing characters survive.
- **The GUI touches Tk widgets only from the main thread.** The worker posts
  `(kind, payload)` messages to a queue that the Tk loop drains on a timer,
  which is the supported way to use tkinter from a background thread.

## Using it as a library

```python
from netcheck import diagnose_host

report = diagnose_host("example.com", use_ai=False)
print(report.all_ok)
for probe in report.probes:
    print(probe.name, probe.ok, probe.elapsed_s)
```

## Adding a provider

Write a function that takes a prompt and returns a string, then register it in
`analyze()` in `analyzer.py` and add the name to `PROVIDERS`. Raise
`AnalyzerError` for anything the user could fix — a missing key, an
uninstalled SDK — and it will be reported cleanly instead of crashing.

## Limitations

- The diagnosis is advisory. It reasons only over what the four probes captured
  and cannot see your firewall rules, routing tables, or application logs.
- ICMP and traceroute are frequently rate-limited or blocked outright; absence
  of a reply is not proof of an outage. The prompt accounts for this, but it's
  worth remembering when reading any result.
- TCP connect checks confirm that something accepted the connection, not that
  the service behind the port is healthy.
- Probe output is sent to a third-party API when the AI step is enabled. Use
  `--no-ai` for hosts whose names or addresses are sensitive.

## Possible extensions

MTU/fragmentation discovery · TLS certificate and expiry inspection · HTTP
status and header checks · `--watch` for continuous monitoring · comparing a
run against a known-good baseline.

## License

MIT — see [LICENSE](LICENSE).
