"""Command-line interface: argument parsing and report rendering."""

from __future__ import annotations

import argparse
import json
import sys

from . import __version__
from .analyzer import API_KEY_ENV, DEFAULT_PROVIDER, PROVIDERS
from .core import Report, TargetError, diagnose_host
from .runner import DEFAULT_PORTS

EFFORT_LEVELS = ("low", "medium", "high", "xhigh", "max")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="netcheck",
        description=(
            "Run ping, traceroute, DNS and TCP port checks against a host, "
            "then ask an LLM to diagnose the raw output."
        ),
        epilog=(
            "The AI step needs an API key: ANTHROPIC_API_KEY by default, or "
            "OPENAI_API_KEY with --provider openai. Use --no-ai to skip it. "
            "See README.md for details."
        ),
    )
    parser.add_argument("target", help="hostname, IP address, or URL to check")
    parser.add_argument(
        "-p",
        "--port",
        dest="ports",
        type=int,
        action="append",
        default=[],
        metavar="PORT",
        help=f"extra TCP port to check; repeatable (defaults: {', '.join(map(str, DEFAULT_PORTS))})",
    )
    parser.add_argument(
        "--no-ports",
        action="store_true",
        help="skip the defaults; combine with -p to check only the ports you name",
    )
    parser.add_argument("--no-ai", action="store_true", help="skip the LLM diagnosis")
    parser.add_argument(
        "--provider",
        choices=PROVIDERS,
        default=DEFAULT_PROVIDER,
        help=f"LLM provider for the diagnosis (default: {DEFAULT_PROVIDER})",
    )
    parser.add_argument(
        "--effort",
        choices=EFFORT_LEVELS,
        default="medium",
        help="reasoning effort for the diagnosis, Anthropic only (default: medium)",
    )
    parser.add_argument("--json", action="store_true", help="print a JSON report instead of text")
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="print each probe command as it runs"
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return parser


def resolve_ports(args: argparse.Namespace) -> list[int]:
    """Combine the default port list with any -p flags."""
    base: list[int] = [] if args.no_ports else list(DEFAULT_PORTS)
    return base + args.ports


def _configure_streams() -> None:
    """Best-effort UTF-8 output; native tools can emit non-ASCII."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            try:
                reconfigure(encoding="utf-8")
            except (OSError, ValueError):
                pass


def render(report: Report) -> str:
    """Render the report as plain text with the raw output kept verbatim."""
    width = 72
    lines = ["=" * width, f"netcheck: {report.host}", "=" * width, ""]

    for probe in report.probes:
        status = "ok" if probe.ok else ("could not run" if probe.exit_code is None else "problem")
        lines += [
            f"--- {probe.name} [{status}] ({probe.elapsed_s:.1f}s) ".ljust(width, "-"),
            f"$ {probe.command}",
            "",
            probe.output or "(no output)",
            "",
        ]

    diagnosis = report.diagnosis
    if diagnosis is None:
        lines += ["-" * width, "AI diagnosis skipped (--no-ai).", ""]
    elif diagnosis.ok:
        lines += [
            "=" * width,
            f"AI DIAGNOSIS ({diagnosis.provider}/{diagnosis.model})",
            "=" * width,
            "",
            diagnosis.text,
            "",
        ]
    else:
        key = API_KEY_ENV.get(diagnosis.provider, "the provider's API key")
        lines += [
            "-" * width,
            f"AI diagnosis unavailable: {diagnosis.error}",
            f"Set {key} to enable it, or pass --no-ai to silence this notice.",
            "",
        ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    _configure_streams()

    bad_ports = [port for port in args.ports if not 1 <= port <= 65535]
    if bad_ports:
        print(f"error: port out of range 1-65535: {bad_ports}", file=sys.stderr)
        return 2

    try:
        report = diagnose_host(
            args.target,
            ports=resolve_ports(args),
            use_ai=not args.no_ai,
            provider=args.provider,
            effort=args.effort,
            verbose=args.verbose,
        )
    except TargetError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\ninterrupted", file=sys.stderr)
        return 130

    if args.json:
        print(json.dumps(report.as_dict(), indent=2, ensure_ascii=False))
    else:
        print(render(report))

    # Exit code reflects the probes only, so a missing API key never masks a
    # healthy target (or vice versa).
    return 0 if report.all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
