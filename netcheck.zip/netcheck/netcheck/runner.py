"""Network probes: ping, traceroute, DNS and TCP port checks.

Each probe shells out to the platform's native tool (ping, tracert /
traceroute, nslookup / dig) so results match what the user's own stack
produces, and captures the output verbatim. Raw output is never rewritten:
it is printed to the user and handed to the LLM unmodified, so the AI
diagnoses exactly the evidence the user is looking at.
"""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Iterable

IS_WINDOWS = os.name == "nt"

PING_COUNT = 4
TRACEROUTE_MAX_HOPS = 20
PORT_TIMEOUT_S = 3.0
PORT_CONCURRENCY = 8
DEFAULT_PORTS = (22, 80, 443)

# Per-probe subprocess budgets, in seconds. Traceroute legitimately takes a
# while (hops x probes x per-probe wait), so it gets a much longer budget.
PROBE_TIMEOUTS = {"ping": 30, "traceroute": 90, "dns": 20}


def _encoding() -> str:
    """Windows console tools emit the OEM codepage; everything else is UTF-8."""
    return "oem" if IS_WINDOWS else "utf-8"


@dataclass
class ProbeResult:
    """Outcome of one diagnostic probe.

    ``exit_code`` is ``None`` when the tool itself could not run - a missing
    binary, or one killed by its timeout budget.
    """

    name: str
    target: str
    command: str
    exit_code: int | None
    output: str
    elapsed_s: float

    @property
    def ok(self) -> bool:
        return self.exit_code == 0

    def as_dict(self) -> dict:
        return {
            "name": self.name,
            "target": self.target,
            "command": self.command,
            "ok": self.ok,
            "exit_code": self.exit_code,
            "elapsed_s": round(self.elapsed_s, 2),
            "output": self.output,
        }


def _run_tool(
    name: str,
    target: str,
    argv: list[str],
    timeout: int,
    verbose: bool = False,
) -> ProbeResult:
    """Run one native command and capture its raw stdout+stderr."""
    if verbose:
        print(f"[netcheck] $ {' '.join(argv)}", file=sys.stderr)
    start = time.monotonic()
    try:
        proc = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            encoding=_encoding(),
            errors="replace",
            timeout=timeout,
        )
        output = (proc.stdout or "") + (proc.stderr or "")
        exit_code = proc.returncode
    except FileNotFoundError:
        output = f"[error] '{argv[0]}' was not found on PATH; install it and retry"
        exit_code = None
    except subprocess.TimeoutExpired as exc:
        partial = exc.stdout if isinstance(exc.stdout, str) else ""
        output = f"[error] '{argv[0]}' exceeded its {timeout}s budget"
        if partial.strip():
            output += f" (partial output follows)\n{partial}"
        exit_code = None
    elapsed = time.monotonic() - start
    return ProbeResult(name, target, " ".join(argv), exit_code, output.strip(), elapsed)


def run_ping(host: str, verbose: bool = False) -> ProbeResult:
    """ICMP echo requests: reachability, round-trip latency and packet loss."""
    if IS_WINDOWS:
        # -n count, -w per-reply wait in milliseconds
        argv = ["ping", "-n", str(PING_COUNT), "-w", "4000", host]
    else:
        # -c count, -W per-reply wait in seconds
        argv = ["ping", "-c", str(PING_COUNT), "-W", "4", host]
    return _run_tool("ping", host, argv, PROBE_TIMEOUTS["ping"], verbose)


def run_traceroute(host: str, verbose: bool = False) -> ProbeResult:
    """Hop-by-hop path to the host: shows where packets stop making progress."""
    if IS_WINDOWS:
        argv = ["tracert", "-h", str(TRACEROUTE_MAX_HOPS), "-w", "1000", host]
    else:
        argv = ["traceroute", "-m", str(TRACEROUTE_MAX_HOPS), "-w", "1", host]
    return _run_tool("traceroute", host, argv, PROBE_TIMEOUTS["traceroute"], verbose)


def _getaddrinfo(host: str) -> tuple[str, list[tuple[str, str]] | None]:
    """Resolve through this machine's own resolver.

    Returns a short summary plus a sorted, de-duplicated list of
    ``(family, address)`` pairs - or ``None`` when resolution failed.
    """
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror as exc:
        return f"failed ({exc})", None
    found = sorted({(socket.AddressFamily(fam).name, addr[0]) for fam, _, _, _, addr in infos})
    return f"OK: {len(found)} address(es)", found


def run_dns(host: str, verbose: bool = False) -> ProbeResult:
    """DNS lookup via the native tool, plus this machine's own resolver.

    The Python-side resolution matters because it is what a real client
    process experiences. The native tool can be absent or misleading on its
    own (``dig`` exits 0 even for NXDOMAIN), so both views are reported.
    """
    summary, addresses = _getaddrinfo(host)
    python_section = "\n".join(
        [f"[python socket.getaddrinfo] {summary}"]
        + [f"  {ip}  ({family})" for family, ip in addresses or []]
    )

    if IS_WINDOWS:
        argv = ["nslookup", host]
    else:
        argv = ["dig", "+noall", "+answer", "+comments", host]
    result = _run_tool("dns", host, argv, PROBE_TIMEOUTS["dns"], verbose)

    output = f"{result.output}\n\n{python_section}".strip()
    exit_code = result.exit_code
    if exit_code is None:
        # The native tool could not run at all; judge DNS health by our resolver.
        exit_code = 0 if addresses is not None else 1
    return ProbeResult("dns", host, result.command, exit_code, output, result.elapsed_s)


@dataclass
class PortResult:
    """Outcome of one TCP connect attempt."""

    host: str
    port: int
    status: str  # open | refused | timeout | dns-error | error
    detail: str
    elapsed_s: float

    def format_line(self) -> str:
        return f"  {self.port:>5}/tcp  {self.status:<9}  {self.detail}"


def _check_one_port(host: str, port: int) -> PortResult:
    """Attempt a TCP handshake, classifying the failure mode if it fails."""
    start = time.monotonic()
    try:
        with socket.create_connection((host, port), timeout=PORT_TIMEOUT_S) as sock:
            elapsed = time.monotonic() - start
            ip = sock.getpeername()[0]
            detail = f"connected to {ip}:{port} in {elapsed * 1000:.0f} ms"
            return PortResult(host, port, "open", detail, elapsed)
    except socket.gaierror as exc:
        detail = f"could not resolve host: {exc}"
        status = "dns-error"
    except (socket.timeout, TimeoutError):
        detail = f"no response within {PORT_TIMEOUT_S:.0f}s - typically a firewall drop"
        status = "timeout"
    except ConnectionRefusedError:
        detail = "connection refused - reachable, but nothing listening"
        status = "refused"
    except OSError as exc:
        code = socket.errorcode.get(exc.errno or 0, "?")
        detail = f"OS error {exc.errno} ({code}): {exc.strerror}"
        status = "error"
    return PortResult(host, port, status, detail, time.monotonic() - start)


def run_port_checks(host: str, ports: Iterable[int], verbose: bool = False) -> ProbeResult:
    """TCP connect checks against ``host``, run concurrently."""
    port_list = sorted(set(ports))
    label = f"{host} ({', '.join(str(p) for p in port_list)})"
    if verbose:
        print(f"[netcheck] checking {len(port_list)} port(s) via TCP connect", file=sys.stderr)

    start = time.monotonic()
    with ThreadPoolExecutor(max_workers=min(len(port_list), PORT_CONCURRENCY)) as pool:
        results = list(pool.map(lambda port: _check_one_port(host, port), port_list))
    elapsed = time.monotonic() - start

    open_count = sum(1 for result in results if result.status == "open")
    output = "\n".join(
        [f"TCP connect checks on {host} ({PORT_TIMEOUT_S:.0f}s timeout each, run in parallel)"]
        + [result.format_line() for result in results]
        + [f"{open_count}/{len(results)} open - all checks finished in {elapsed:.1f}s"]
    )
    exit_code = 0 if all(result.status == "open" for result in results) else 1
    return ProbeResult(
        "ports",
        label,
        "python socket.create_connection (parallel)",
        exit_code,
        output,
        elapsed,
    )


def run_all_probes(
    host: str,
    ports: Iterable[int] | None = None,
    verbose: bool = False,
) -> list[ProbeResult]:
    """Run the standard suite: ping, traceroute, DNS, then TCP port checks.

    Probes run in order so the report reads top to bottom the way an engineer
    would work through it; only the port checks fan out in parallel. Pass an
    empty ``ports`` iterable to skip port checks entirely.
    """
    results = [
        run_ping(host, verbose),
        run_traceroute(host, verbose),
        run_dns(host, verbose),
    ]
    if ports:
        results.append(run_port_checks(host, ports, verbose))
    return results
