"""Orchestration: run the probes, then hand the raw output to the analyzer."""

from __future__ import annotations

import re
import socket
from dataclasses import dataclass
from typing import Iterable

from .analyzer import DEFAULT_PROVIDER, Diagnosis, analyze
from .runner import DEFAULT_PORTS, ProbeResult, run_all_probes

# Hostname or IPv4/IPv6 literal. Deliberately permissive - the probes
# themselves are the real validation; this only rejects obvious junk such as
# a pasted URL or a shell fragment.
_HOST_RE = re.compile(r"^[A-Za-z0-9._:\-\[\]%]+$")


class TargetError(ValueError):
    """The supplied target is not usable as a host."""


@dataclass
class Report:
    """Everything one `netcheck` run produced."""

    host: str
    probes: list[ProbeResult]
    diagnosis: Diagnosis | None

    @property
    def all_ok(self) -> bool:
        return all(probe.ok for probe in self.probes)

    def as_dict(self) -> dict:
        return {
            "host": self.host,
            "all_ok": self.all_ok,
            "probes": [probe.as_dict() for probe in self.probes],
            "diagnosis": self.diagnosis.as_dict() if self.diagnosis else None,
        }


def normalize_target(target: str) -> str:
    """Reduce user input to a bare hostname or IP.

    Accepts what people actually paste - ``https://example.com/path``,
    ``example.com:8080`` - and strips it down to the host the probes need.
    """
    host = target.strip()
    if not host:
        raise TargetError("no target given")

    host = re.sub(r"^[A-Za-z][A-Za-z0-9+.\-]*://", "", host)  # scheme
    host = host.split("/", 1)[0]  # path
    host = host.split("@")[-1]  # userinfo

    # Strip a trailing :port, but leave bare IPv6 literals (which are all
    # colons) and bracketed [::1]:443 forms intact.
    if host.startswith("["):
        host = host.split("]", 1)[0].lstrip("[")
    elif host.count(":") == 1:
        host = host.split(":", 1)[0]

    if not host:
        raise TargetError(f"could not extract a host from {target!r}")
    if not _HOST_RE.match(host):
        raise TargetError(f"{host!r} does not look like a hostname or IP address")
    return host


def resolves(host: str) -> bool:
    """Whether this machine's resolver can turn ``host`` into an address."""
    try:
        socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False
    return True


def diagnose_host(
    target: str,
    ports: Iterable[int] | None = None,
    use_ai: bool = True,
    provider: str = DEFAULT_PROVIDER,
    effort: str = "medium",
    verbose: bool = False,
) -> Report:
    """Run the probe suite against ``target`` and optionally diagnose it.

    ``ports`` defaults to :data:`netcheck.runner.DEFAULT_PORTS`; pass an empty
    iterable to skip port checks. Set ``use_ai=False`` to collect raw results
    only - useful offline, in tests, or when no API key is configured.
    """
    host = normalize_target(target)
    port_list = DEFAULT_PORTS if ports is None else list(ports)
    probes = run_all_probes(host, port_list, verbose)
    diagnosis = analyze(host, probes, provider, effort) if use_ai else None
    return Report(host, probes, diagnosis)
