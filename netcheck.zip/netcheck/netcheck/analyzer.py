"""LLM-backed diagnosis of captured probe output.

Anthropic's Claude is the default backend; OpenAI is available as an opt-in
alternative so the tool is not locked to one vendor. Each provider lives in
its own function - the two SDKs are never mixed.

Nothing here is required for the probes to run: if no API key is configured,
`netcheck` still prints the raw results and reports the analyzer as skipped.
"""

from __future__ import annotations

import os
import textwrap
from dataclasses import dataclass

# Claude Opus 5 thinks by default, and max_tokens caps thinking + response
# text together, so leave headroom well above the prose we actually want.
ANTHROPIC_MODEL = "claude-opus-5"
ANTHROPIC_MAX_TOKENS = 8000
OPENAI_MODEL = "gpt-4o"
API_TIMEOUT_S = 180.0

PROVIDERS = ("anthropic", "openai")
DEFAULT_PROVIDER = "anthropic"
API_KEY_ENV = {"anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY"}

SYSTEM_PROMPT = textwrap.dedent(
    """\
    You are a senior network engineer triaging a connectivity problem. You are
    given the raw, unedited output of diagnostic commands run from a user's
    machine against a target host.

    Work only from the evidence in the output. Distinguish clearly between what
    the data shows and what you are inferring; if a probe is inconclusive, say
    so rather than guessing. Note that ICMP echo and traceroute hops are
    routinely rate-limited or dropped by firewalls, so timeouts there are not by
    themselves proof of an outage.

    When something is wrong, structure your answer as these four sections:

    ## Summary
    One or two sentences: is the host reachable, and what is the headline issue?

    ## What the output shows
    The specific findings, each tied to the probe and line that supports it.

    ## Likely causes
    Ranked most to least probable, with your confidence and reasoning.

    ## Suggested next steps
    Concrete, ordered actions the user can take. Prefer commands they can run.
    Say what each step would confirm or rule out.

    When the diagnostics look healthy, do not pad the response out to that
    shape. Say so plainly in a short paragraph, note anything genuinely worth a
    second look, and stop.

    Be concise and specific. Skip preamble, restating the input, and generic
    networking tutorials. Your output is printed by a command-line tool that
    exits immediately, so there is no conversation: never ask the user a
    question, and never offer to run a follow-up yourself. Recommend the
    command for them to run instead.
    """
)


class AnalyzerError(RuntimeError):
    """Raised when diagnosis cannot be produced (config, auth, or API error)."""


@dataclass
class Diagnosis:
    """An AI diagnosis, or the reason one could not be produced."""

    provider: str
    model: str
    text: str | None
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.text is not None

    def as_dict(self) -> dict:
        return {
            "provider": self.provider,
            "model": self.model,
            "ok": self.ok,
            "text": self.text,
            "error": self.error,
        }


def build_prompt(host: str, probes: list) -> str:
    """Assemble the raw probe output into a single prompt.

    Probe output is embedded verbatim inside fenced blocks - the LLM diagnoses
    exactly the bytes the user sees on their terminal.
    """
    sections = [
        f"Target host: {host}",
        f"Probes run from: {os.name} platform",
        "",
    ]
    for probe in probes:
        status = "exit 0" if probe.ok else f"exit {probe.exit_code}"
        sections.append(f"### {probe.name} ({status}, {probe.elapsed_s:.1f}s)")
        sections.append(f"Command: `{probe.command}`")
        sections.append("```")
        sections.append(probe.output or "(no output)")
        sections.append("```")
        sections.append("")
    sections.append(f"Diagnose the connectivity situation for {host}.")
    return "\n".join(sections)


def _analyze_with_anthropic(prompt: str, effort: str) -> str:
    try:
        import anthropic
    except ImportError as exc:
        raise AnalyzerError(
            "the 'anthropic' package is not installed - run: pip install netcheck[anthropic]"
        ) from exc

    try:
        # Resolves ANTHROPIC_API_KEY, ANTHROPIC_AUTH_TOKEN, or an `ant auth
        # login` profile. Raises if it finds no usable credential.
        #
        # The user has already waited through the probe suite by this point, so
        # retry a transient blip rather than discarding the run. The 10-minute
        # SDK default timeout is far too long to leave a CLI hanging.
        client = anthropic.Anthropic(max_retries=3, timeout=API_TIMEOUT_S)
    except Exception as exc:
        raise AnalyzerError(f"could not build an Anthropic client ({exc})") from exc

    try:
        # Network diagnostics sit near the API's cybersecurity classifiers, so a
        # benign run can occasionally be declined. Server-side fallbacks re-run
        # the request on Anthropic's recommended model instead of failing.
        response = client.beta.messages.create(
            model=ANTHROPIC_MODEL,
            max_tokens=ANTHROPIC_MAX_TOKENS,
            system=SYSTEM_PROMPT,
            output_config={"effort": effort},
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            messages=[{"role": "user", "content": prompt}],
        )
    except anthropic.AuthenticationError as exc:
        raise AnalyzerError(f"authentication failed - check ANTHROPIC_API_KEY ({exc})") from exc
    except anthropic.PermissionDeniedError as exc:
        raise AnalyzerError(f"API key lacks access to {ANTHROPIC_MODEL} ({exc})") from exc
    except anthropic.NotFoundError as exc:
        raise AnalyzerError(f"model {ANTHROPIC_MODEL} was not found ({exc})") from exc
    except anthropic.RateLimitError as exc:
        retry_after = exc.response.headers.get("retry-after", "?")
        raise AnalyzerError(f"rate limited - retry in {retry_after}s") from exc
    except anthropic.APIConnectionError as exc:
        raise AnalyzerError(f"could not reach the Anthropic API ({exc})") from exc
    except anthropic.APIStatusError as exc:
        raise AnalyzerError(f"API error {exc.status_code}: {exc.message}") from exc

    # Check stop_reason before reading content: a refused request returns 200
    # with an empty (or partial) content list.
    if response.stop_reason == "refusal":
        detail = getattr(response.stop_details, "explanation", None) or "no explanation given"
        raise AnalyzerError(f"the model declined to answer ({detail})")

    text = "\n".join(block.text for block in response.content if block.type == "text").strip()
    if not text:
        raise AnalyzerError(f"the model returned no text (stop_reason={response.stop_reason})")
    if response.stop_reason == "max_tokens":
        text += "\n\n_[truncated: hit the max_tokens limit]_"
    return text


def _analyze_with_openai(prompt: str) -> str:
    try:
        import openai
    except ImportError as exc:
        raise AnalyzerError(
            "the 'openai' package is not installed - run: pip install netcheck[openai]"
        ) from exc

    try:
        client = openai.OpenAI()  # resolves OPENAI_API_KEY
    except Exception as exc:
        raise AnalyzerError(f"could not build an OpenAI client ({exc})") from exc

    try:
        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )
    except openai.AuthenticationError as exc:
        raise AnalyzerError(f"authentication failed - check OPENAI_API_KEY ({exc})") from exc
    except openai.RateLimitError as exc:
        raise AnalyzerError(f"rate limited by the OpenAI API ({exc})") from exc
    except openai.APIConnectionError as exc:
        raise AnalyzerError(f"could not reach the OpenAI API ({exc})") from exc
    except openai.APIStatusError as exc:
        raise AnalyzerError(f"API error {exc.status_code}: {exc.message}") from exc

    text = (response.choices[0].message.content or "").strip()
    if not text:
        raise AnalyzerError("the model returned no text")
    return text


def analyze(host: str, probes: list, provider: str = DEFAULT_PROVIDER, effort: str = "medium") -> Diagnosis:
    """Ask an LLM to diagnose the captured probe output.

    Never raises: a failure is reported on the returned ``Diagnosis`` so the
    raw probe results are still printed. ``effort`` applies to Anthropic only.
    """
    model = ANTHROPIC_MODEL if provider == "anthropic" else OPENAI_MODEL
    prompt = build_prompt(host, probes)
    try:
        if provider == "anthropic":
            text = _analyze_with_anthropic(prompt, effort)
        elif provider == "openai":
            text = _analyze_with_openai(prompt)
        else:
            raise AnalyzerError(f"unknown provider '{provider}' (expected one of {PROVIDERS})")
    except AnalyzerError as exc:
        return Diagnosis(provider, model, None, str(exc))
    return Diagnosis(provider, model, text)
