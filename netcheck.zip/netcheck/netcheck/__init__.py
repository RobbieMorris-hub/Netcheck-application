"""netcheck - CLI network diagnostics with LLM-powered diagnosis.

Runs ping, traceroute, DNS resolution and TCP port checks against a host,
captures the raw output, and asks an LLM to interpret it::

    $ netcheck example.com

The package is also usable as a library::

    from netcheck import diagnose_host

    report = diagnose_host("example.com", use_ai=False)
"""

from .core import diagnose_host
from .runner import DEFAULT_PORTS, ProbeResult

__version__ = "0.1.0"
__all__ = ["diagnose_host", "DEFAULT_PORTS", "ProbeResult", "__version__"]
